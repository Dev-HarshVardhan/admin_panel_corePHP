<?php
require_once('header.php');
require_once('db_connect.php');

// Check if update_id is provided in the URL
if(isset($_GET['update_id'])){
    $id = $_GET['update_id'];

    // Fetch the news article details based on ID
    $sql = "SELECT * FROM district WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result);
}


if(isset($_POST['submit'])){
    $state = $_POST['state'];
    $district= $_POST['district'];

    // Update the news article in the database
    $query = "UPDATE district SET state_id='$state', district_name='$district' WHERE id='$id'";
    $execute = mysqli_query($conn, $query);
    
    if($execute){
        echo '<script>
                 Swal.fire({
                   title: "Success!",
                   text: "Record Update successfully.",
                   icon: "success"
                 }).then(function() {
                     window.location = "show_district.php"; // Redirect to show_news.php
                 });
              </script>';
    } else {
        echo 'Data Not Updated';
    }
}
?>
<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5 ">
        <div class="card">
             <div class="card-header">
                <div class="card-title text-center">Update District </div>
            </div>
            <form method="POST">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                        <div class="form-group">
                                <label for="image">Select State</label>
                               <select name="state" id="state" class="form-control">
                                <option value="">Select State</option>
                                <?php
                                $sql="select * from states";
                                $result=mysqli_query($conn,$sql);
                                $num_rows=mysqli_num_rows($result);

                                ?>
                                <?php if($num_rows > 0): ?>
                                    <?php while($row=mysqli_fetch_assoc($result)): ?>
                                        <option value="<?php echo $row['id']; ?>"
                                        <?php if($row['id'] == $data['state_id']) echo 'selected'; ?>>
                                        <?php echo $row['state_name']; ?></option>
                                        <?php endwhile; ?>
                                <?php endif; ?>
                               </select>
                            </div>
                            <div class="form-group">
                                <label for="image">District Name</label>
                                <input type="text" name="district" value="<?php echo $data['district_name']; ?>" required class="form-control"/>
                            </div>
                            
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
