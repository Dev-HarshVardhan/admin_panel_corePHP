<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB_NAME','dr_suresh');
define('SHOW',false);


$conn=mysqli_connect(HOST,USER,PASS,DB_NAME);
if($conn){
    if(SHOW==true){
        echo 'Connection Successfully..';
    }
}else{
    echo 'Connection Error..';
}



?>