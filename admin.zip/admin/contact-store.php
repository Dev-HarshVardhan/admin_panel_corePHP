<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.12.1/dist/sweetalert2.min.css" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    
</body>
</html>
<?php 
include("db_connect.php"); 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once '../vendor_msg/autoload.php';
require '../vendor_msg/PHPMailer/src/Exception.php';
require '../vendor_msg/PHPMailer/src/PHPMailer.php';
require '../vendor_msg/PHPMailer/src/SMTP.php';

if (isset($_POST['submit'])) {
    $fname = $_POST['firstname'];
    $lname = $_POST['lastname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $msg = $_POST['message'];

    $mail = new PHPMailer();

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'bookyourenquiry@gmail.com';
    $mail->Password = 'kcqtllrzflqjcciq';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('bookyourenquiry@gmail.com', 'Dr. Suresh Mandal');
    $mail->addAddress('bookyourenquiry@gmail.com', 'Contact Form'); 
    $mail->Subject = 'Contact Form';
     
    $txt = "Dear {$fname} {$lname},<br><br>";
    $txt .= "Email Id: {$email} <br><br>";
    $txt .= "Phone: {$phone} <br><br>";
    $txt .= "Message: {$msg} <br><br>";
    $txt .= "<strong>Best regards,</strong> <br>";
    $txt .= "Our Team";
   
    $html_body = $txt;
    $mail->msgHTML($html_body);

    if ($mail->send()) {
        $sql = "INSERT INTO contact_us (fname, lname, email, phone, message) VALUES ('$fname','$lname' ,'$email', '$phone', '$msg')";
        $run_query = mysqli_query($conn, $sql);

        if ($run_query) {
           echo '<script>
           swal({
            title: "Success!",
            text: "Your message has been successfully sent.",
            icon: "success"
        }).then(function() {
            window.location.href = "../index.php";
        });</script>';
        } else {
            echo '<script>
           swal({
            title: "Error!",
            text: "Your message has been Not sent.",
            icon: "error"
        }).then(function() {
            window.location.href = "../index.php";
        });</script>';
        }
    } else {
        echo '<script>
           swal({
            title: "Error!",
            text: "OOPs Somethimg Error",
            icon: "error"
        }).then(function() {
            window.location.href = "../index.php";
        });</script>';
    }

}
?>
