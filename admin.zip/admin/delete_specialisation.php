<?php
require_once('header.php');
require_once('db_connect.php');
if(isset($_GET['delete_id'])){
    $id=$_GET['delete_id'];
    $sql="delete from Specialisation where id=$id";
    $result=mysqli_query($conn,$sql);
    if($result){
        echo '<script>
                 Swal.fire({
                   title: "Success!",
                   text: "Record Delete successfully.",
                   icon: "success"
                 }).then(function() {
                     window.location = "show_specialisation.php";
                 });
              </script>';
    }else{
        echo '<script>
             Swal.fire({
               title: "Data not Delete!",
               text: "You clicked the button!",
               icon: "Error"
             });
              </script>';
    }
}
?>