<!DOCTYPE html>
<html lang="en">


<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="" />
<meta name="keywords" content="" />
<link rel="icon" href="assets/images/favicon.png" sizes="35x35" type="image/png">
<title>SRB Group | Pellet Plant</title>

<link rel="stylesheet" href="assets/css/all.min.css">
<link rel="stylesheet" href="assets/css/flaticon.css">
<link rel="stylesheet" href="assets/css/animate.min.css">
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">
<link rel="stylesheet" href="assets/css/perfect-scrollbar.css">
<link rel="stylesheet" href="assets/css/slick.css">
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/responsive.css">
<link rel="stylesheet" href="assets/css/color.css">
<link rel="stylesheet" href="assets/css/new.style.css">
</head>
<body>
<main>


<?php include('inc/header.php');?>	


<section>
<div class="w-100 pt-170 pb-150 dark-layer3 opc7 position-relative">
<div class="fixed-bg" style="background-image: url(img/technology1.jpg);"></div>
<div class="container">
<div class="page-top-wrap w-100">
<h1 class="mb-0">Pellet Plant</h1>
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="index.php" title="">Home</a></li>
<li class="breadcrumb-item active">Pellet Plant</li>
</ol>
</div><!-- Page Top Wrap -->
</div>
</div>
</section>


<section>
<div class="w-100 pt-100 pb-100 position-relative">
<div class="container">
<div class="about-wrap style2 w-100">
<div class="row align-items-center justify-content-center">





<div class="col-md-12 col-sm-12 col-lg-12">
<div class="about-desc Ul_lsit w-100 content_desc">
<h2 class="mb-20">Pellet Plant</h2>
<div class="tie-ups">
<img class="img-fluid w-100" src="img/technology/sintering.jpg" alt="About Image 2">
</div>


 <p>We supply travelling grate induration machines for pellet production (iron ore, phosphorite type, etc.). About 50 complexes with induration machines have been developed and put into operation with working area of 108-592 sq.m.</p>
 <p>The plant is offered with new generation induration machines of any working area and capacity. Including Revamping of existing pellet plants with application of modern technological processes and efficient gas flow patterns and the re-use of the existing production facilities, foundations and utility lines. Equipment such as Drum Pelletizers, Disc Pelletizers green pellets screening, Induration machines, Pallet cars, Vibration screen.</p>
</div>
</div>




</div>
</div>

</div><!-- About Wrap -->
</div>
</div>
</section>	

  





























<?php include('inc/footer.php');?>	  

</main><!-- Main Wrapper -->

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/counterup.min.js"></script>
<script src="assets/js/jquery.fancybox.min.js"></script>
<script src="assets/js/perfect-scrollbar.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/particles.min.js"></script>
<script src="assets/js/particle-int.js"></script>
<script src="assets/js/custom-scripts.js"></script>
</body>	


</html>