<!------------------------------Gete the Data ----------------------------------------->
<?php
require_once("db_connect.php");
if(isset($_POST['id'])){
    $id=$_POST['id'];
    $sql="select * from district where state_id='$id'";
    $result=mysqli_query($conn,$sql);
    while($row=mysqli_fetch_assoc($result)){
        $id=$row['id'];
        $district=$row['district_name'];
        echo "<option value='$id'>$district</option>";
    }
}
?>
<!------------------------------Gete the Data ----------------------------------------->

