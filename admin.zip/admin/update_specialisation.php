<?php
require_once('header.php');
require_once('db_connect.php');

// Check if update_id is provided in the URL
if(isset($_GET['update_id'])){
    $id = $_GET['update_id'];

    // Fetch the news article details based on ID
    $sql = "SELECT * FROM specialisation WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result);
}


if(isset($_POST['submit'])){
    $state = $_POST['specialisation'];

    // Update the news article in the database
    $query = "UPDATE Specialisation SET name='$state' WHERE id='$id'";
    $execute = mysqli_query($conn, $query);
    
    if($execute){
        // Success message using SweetAlert
        echo '<script>
                 Swal.fire({
                   title: "Success!",
                   text: "Record Update successfully.",
                   icon: "success"
                 }).then(function() {
                     window.location = "show_specialisation.php"; 
                 });
              </script>';
    } else {
        echo 'Data Not Updated';
    }
}
?>
<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5">
        <div class="card">
            <div class="card-header">
                <div class="card-title text-center">Update Specialisation</div>
            </div>
            <form method="POST">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                            <div class="form-group">
                                <label for="email2">Specialisation Name</label>
                                <input type="text" name="specialisation" required value="<?php echo $data['name']; ?>" class="form-control" id="email2" placeholder="News Title"/>
                            </div>
                           
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
