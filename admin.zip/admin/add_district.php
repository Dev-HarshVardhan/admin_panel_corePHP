<?php
require_once("header.php");
require_once("db_connect.php");
if(isset($_POST["submit"])){
    $state=$_POST['state'];
    $district=$_POST['district'];
    $query="insert into district(state_id,district_name) values('$state','$district')";
    $execute=mysqli_query($conn,$query);
    if($execute){
        echo '<script>
           swal({
            title: "Success!",
            text: "Record Insert Successfully",
            icon: "success"
        }).then(function() {
            window.location.href = "add_district.php";
        });</script>';
    }else{
        echo 'error';
    }
}
?>

<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5 ">
        <div class="card">
             <div class="card-header">
                <div class="card-title text-center">Add District </div>
            </div>
            <form method="POST">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                        <div class="form-group">
                                <label for="image">Select State</label>
                               <select name="state" required id="state" class="form-control">
                                <option value="">Select State</option>
                                <?php
                                $sql="select * from states";
                                $result=mysqli_query($conn,$sql);
                                $num_rows=mysqli_num_rows($result);

                                ?>
                                <?php if($num_rows > 0): ?>
                                    <?php while($row=mysqli_fetch_assoc($result)): ?>
                                        <option value="<?php echo $row['id']; ?>"><?php echo $row['state_name']; ?></option>
                                        <?php endwhile; ?>
                                <?php endif; ?>
                               </select>
                            </div>
                            <div class="form-group">
                                <label for="image">District Name</label>
                                <input type="text" name="district" required class="form-control"/>
                            </div>
                            
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>