<?php
require_once("header.php");
require_once("db_connect.php");
if(isset($_POST["submit"])){
    $allowed_extensions = "/(png|jpeg|jpg|webp|pdf)$/i";

    $gallery=$_FILES['gallery_image']['name'];
    $tmp_path=$_FILES['gallery_image']['tmp_name'];
    $file_extension = pathinfo($gallery, PATHINFO_EXTENSION);

    if (!preg_match($allowed_extensions,$file_extension)) {
echo '
<script>
Swal.fire({
title: "Extension not Allowed!",
text: "Invalid file format. Allowed formats are: PNG, JPG, JPEG, WEBP.",
icon: "error"
});
</script>';
    }else{
        $upload_path="photo/upload_image/".$gallery;
        if(move_uploaded_file($tmp_path,$upload_path)){

            $query="insert into gallery(image) values('$gallery')";
            $execute=mysqli_query($conn,$query);
            if($execute){
                    echo '<script>
                       swal({
                        title: "Success!",
                        text: "Record Insert Successfully",
                        icon: "success"
                    }).then(function() {
                        window.location.href = "add_gallery.php";
                    });</script>';
                }else{
                    echo 'error';
                }
        }else{
            echo '<script>
            Swal.fire({
              title: "Error!",
              text: "Failed to move uploaded file.",
              icon: "error"
            });
             </script>';
        }
    }
   
}
?>

<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5 ">
        <div class="card">
             <div class="card-header">
                <div class="card-title text-center">Add Gallery </div>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                            <div class="form-group">
                                <label for="image">Gallery Image</label>
                                <input type="file" name="gallery_image" required class="form-control" />
                            </div>
                            
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>