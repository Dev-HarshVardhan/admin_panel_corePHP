<?php
session_start();
require_once('db_connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if (!$result || mysqli_num_rows($result) == 0) {
        // No user found with the given email
        echo "no_user_found";
    } else {
        $row = mysqli_fetch_assoc($result);
        $dbHash = $row['password'];

        if (password_verify($password, $dbHash)) {
            $_SESSION['email'] = $row['email'];
            $_SESSION['login_success'] = true;
            echo "success";
        } else {
            echo "invalid_password";
        }
    }
} else {
    header("location: index.php");
    exit();
}
?>
