<?php
require_once('header.php');
require_once('db_connect.php');

// Check if update_id is provided in the URL
if(isset($_GET['update_id'])){
    $id = $_GET['update_id'];

    // Fetch the news article details based on ID
    $sql = "SELECT * FROM city WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result);
}


if(isset($_POST['submit'])){
    $state = $_POST['state'];
    $district= $_POST['district'];
    $city= $_POST['city'];

    // Update the news article in the database
    $query = "UPDATE city SET state_id='$state', district_id='$district',city_name='$city' WHERE id='$id'";
    $execute = mysqli_query($conn, $query);
    
    if($execute){
        echo '<script>
                 Swal.fire({
                   title: "Success!",
                   text: "Record Update successfully.",
                   icon: "success"
                 }).then(function() {
                     window.location = "show_city.php"; // Redirect to show_news.php
                 });
              </script>';
    } else {
        echo 'Data Not Updated';
    }
}
?>
<?php
       
  ?>
<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5 ">
        <div class="card">
             <div class="card-header">
                <div class="card-title text-center">Update City </div>
            </div>
            <form method="POST">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                        <div class="form-group">
                                <label for="image">Select State</label>
                                <select name="state" id="state" class="form-control">
                                <option value="">Select State</option>
                                <?php
                                $sql="select * from states";
                                $result_state=mysqli_query($conn,$sql);
                                $num_rows_state=mysqli_num_rows($result_state);
                                ?>
                                <?php if($num_rows_state > 0): ?>
                                    <?php while($state=mysqli_fetch_assoc($result_state)): ?>
                                        <option value="<?php echo $state['id']; ?>"
                                        <?php if($state['id'] == $data['state_id']) echo 'selected'; ?>>
                                        <?php echo $state['state_name']; ?></option>
                                        <?php endwhile; ?>
                                <?php endif; ?>
                               </select>
                            </div>
                            <div class="form-group">
                                <label for="image">Select District</label>
                               <select name="district" id="district" class="form-control">
                                <option value="">Select District</option>
                                  <?php 
                                  $sql="select * from district";
                                  $result=mysqli_query($conn,$sql);
                                  $num_rows_dist=mysqli_num_rows($result);
                                  
                                  ?>
                                <?php if($num_rows_dist > 0): ?>
                                    <?php
                                        while($dist_data=mysqli_fetch_assoc($result)): ?>
                                        <option value="<?php echo $dist_data['id']; ?>"
                                        <?php if($dist_data['id'] == $data['district_id']) echo 'selected'; ?>>
                                        <?php echo $dist_data['district_name']; ?></option>
                                        <?php endwhile; ?>
                                <?php endif; ?>
                               </select>
                            </div>
                            <div class="form-group">
                                <label for="image">City Name</label>
                                <input type="text" name="city" value="<?php echo $data['city_name']; ?>" required class="form-control"/>
                            </div>
                            
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
    $("#state").on("change",function(){
        var state_id=$(this).val();
        $.ajax({
            method:"POST",
            url:"ajax.php",
            data:{id:state_id},
            dataType:"html",
            success:function(data){
                $("#district").html(data);
            }
        });
    });
});
</script>
