<?php
require_once("header.php");
require_once("db_connect.php");
if(isset($_POST['submit'])){
    $post_by=$_POST['post_by'];
    $title=$_POST['title'];
    $description=$_POST['description'];
    $date=$_POST['date'];

    $post_by=mysqli_real_escape_string($conn,$post_by);
    $title=mysqli_real_escape_string($conn,$title);
    $description=mysqli_real_escape_string($conn,$description);
    
    $post_image=$_FILES['image']['name'];
    $tmp_path=$_FILES['image']['tmp_name'];
    $allowed_extensions = "/(png|jpeg|jpg|webp)$/i";
    $file_extension= pathinfo($post_image,PATHINFO_EXTENSION);
    if(!preg_match($allowed_extensions,$file_extension)){
        echo '
            <script>
            Swal.fire({
            title: "Extension not Allowed!",
            text: "Invalid file format. Allowed formats are: PNG, JPG, JPEG, WEBP.",
            icon: "error"
            });
            </script>';
    }else{
        $upload_path="photo/blog_image/".$post_image;
        if(move_uploaded_file($tmp_path,$upload_path)){
            $query="insert into blog(post_by,title,description,image,date) values('$post_by','$title','$description','$post_image','$date')";
            $result=mysqli_query($conn,$query);
            if($result){
                echo '<script>
                        swal({
                            title: "Success!",
                            text: "Record Insert Successfully",
                            icon: "success"
                        }).then(function() {
                            window.location.href = "add_blog.php";
                        });</script>';
            }else{
                echo '<script>
                    Swal.fire({
                    title: "Error!",
                    text: "OOPS Something Error",
                    icon: "error"
                    });
                    </script>';
            }
        }else{
            echo '<script>
                Swal.fire({
                title: "Error!",
                text: "Failed to move uploaded file.",
                icon: "error"
                });
                </script>';
        }
    }
}
?>

<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5 ">
        <div class="card">
             <div class="card-header">
                <div class="card-title text-center">Add Blog </div>
            </div>
        <form method="POST" enctype="multipart/form-data">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                        <div class="form-group">
                                <label for="image">Posted By</label>
                                <input type="text" name="post_by" required class="form-control" />
                            </div>
                        <div class="form-group">
                                <label for="image">Title</label>
                                <input type="text" name="title" required class="form-control" />
                            </div>
                        <div class="form-group">
                                <label for="image">Description</label>
                                <textarea type="text" name="description" required id="editor1" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="image">Blog Image</label>
                                <input type="file" name="image" required class="form-control" />
                            </div>
                            <div class="form-group">
                                <label for="image">Date</label>
                                <input type="date" name="date" required class="form-control" />
                            </div>
                            
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.ckeditor.com/4.4.5/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('editor1');
    </script>