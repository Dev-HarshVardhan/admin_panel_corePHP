<?php
require_once("db_connect.php");
require_once("header.php");



?>
<div class="col-md-6 col-lg-10 mx-auto " style="margin-top: 100px;">
                        <div class="form-group">
                                <label for="state">Select State</label>
                               <select name="state" id="state" class="form-control">
                                <option value="">Select State</option>
                                <?php
                                $sql="select * from states";
                                $result=mysqli_query($conn,$sql);
                                $num_rows=mysqli_num_rows($result);

                                ?>
                                <?php if($num_rows > 0): ?>
                                    <?php while($row=mysqli_fetch_assoc($result)): ?>
                                        <option value="<?php echo $row['id']; ?>"><?php echo $row['state_name']; ?></option>
                                        <?php endwhile; ?>
                                <?php endif; ?>
                               </select>
                            </div>
                            <div class="form-group">
                                <label for="district">District Name</label>
                               <select name="district" id="district" class="form-control">
                                <option value=""></option>
                               </select>
                            </div>
                            <div class="form-group">
                                <label for="city">City Name</label>
                                <input type="text" name="city" id="city" required class="form-control" />
                            </div>
                            
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Submit</button>
                            </div>
                        </div>
<script>
    $(document).ready(function(){
    $("#state").on("change",function(){
        var state_id=$(this).val();
        $.ajax({
            method:"POST",
            url:"ajax.php",
            data:{id:state_id},
            dataType:"html",
            success:function(data){
                $("#district").html(data);
            }
        });
    });
});
</script>