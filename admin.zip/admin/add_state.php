<?php 

require_once('header.php');
require_once('db_connect.php');
if(isset($_POST['submit'])){
    $state=$_POST['state'];
  
    $state_name=mysqli_real_escape_string($conn,$state);
  
    
    $query="insert into states(state_name) values('$state_name')";
    $result=mysqli_query($conn,$query);
    if($result){
        echo '<script>
        Swal.fire({
          title: "Success!",
          text: "Record Insert successfully.",
          icon: "success"
        }).then(function() {
            window.location = "add_state.php"; // Redirect to show_news.php
        });
     </script>';
    }else{
        echo 'error';
    }
}
?>
?>
<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5 ">
        <div class="card">
             <div class="card-header">
                <div class="card-title text-center">Add State </div>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                            <div class="form-group">
                                <label for="image">State Name</label>
                                <input type="text" name="state" required class="form-control" />
                            </div>
                            
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>