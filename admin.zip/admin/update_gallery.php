<?php
require_once('header.php');
require_once('db_connect.php');

// Check if update_id is provided in the URL
if (isset($_GET['update_id'])) {
    $id = $_GET['update_id'];

    // Fetch the news article details based on ID
    $sql = "SELECT * FROM gallery WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result);
}

if (isset($_POST['submit'])) {
    if (!empty($_FILES['gallery_image']['name'])) {
        $gallery = $_FILES['gallery_image']['name'];
        $tmp_path = $_FILES['gallery_image']['tmp_name'];
        $allowed_extensions = "/(png|jpeg|jpg|webp|pdf)$/i";
        $file_extension = pathinfo($gallery, PATHINFO_EXTENSION);

        if (!preg_match($allowed_extensions, $file_extension)) {
            echo '<script>
                Swal.fire({
                title: "Extension not Allowed!",
                text: "Invalid file format. Allowed formats are: PNG, JPG, JPEG, WEBP.",
                icon: "error"
                });
                </script>';
        } else {
            $upload_path = "photo/upload_image/" . $gallery;
            if (move_uploaded_file($tmp_path, $upload_path)) {
                $query = "UPDATE gallery SET image='$gallery' WHERE id='$id'";
                $execute = mysqli_query($conn, $query);
                if ($execute) {
                    echo '<script>
                        Swal.fire({
                            title: "Success!",
                            text: "Record Updated Successfully",
                            icon: "success"
                        }).then(function() {
                            window.location.href = "show_gallery.php";
                        });
                    </script>';
                } else {
                    echo 'Error updating record.';
                }
            } else {
                echo 'Error moving uploaded file.';
            }
        }
    } else {
        $gallery = $data['image'];
        $query = "UPDATE gallery SET image='$gallery' WHERE id='$id'";
        $execute = mysqli_query($conn, $query);
        if ($execute) {
            echo '<script>
                Swal.fire({
                    title: "Success!",
                    text: "Record Updated Successfully",
                    icon: "success"
                }).then(function() {
                    window.location.href = "show_gallery.php";
                });
            </script>';
        } else {
            echo 'Error updating record.';
        }
    }
}
?>

<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5">
        <div class="card">
            <div class="card-header">
                <div class="card-title text-center">Update Gallery</div>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                            <div class="form-group">
                                <label for="gallery_image">Gallery Image</label>
                                <input type="file" name="gallery_image" class="form-control" id="gallery_image" />
                                <img src="photo/upload_image/<?php echo $data['image']; ?>" height="50px" alt="">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
