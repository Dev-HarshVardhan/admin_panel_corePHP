<?php
require_once("header.php");
require_once("db_connect.php");
if(isset($_POST['submit'])){
    $specialisation=$_POST['specialisation'];
    $sql="insert into specialisation(name) values('$specialisation')";
    $result=mysqli_query($conn,$sql);
    if($result){
        echo '<script>
           swal({
            title: "Success!",
            text: "Record Insert Successfully",
            icon: "success"
        }).then(function() {
            window.location.href = "add_specialisation.php";
        });</script>';
    }else{
        echo '<script>
           swal({
            title: "Error!",
            text: "Please try again",
            icon: "error"
        }).then(function() {
            window.location.href = "add_specialisation.php";
        });</script>';
    }
}
?>

<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5 ">
        <div class="card">
             <div class="card-header">
                <div class="card-title text-center">Add Specialisation </div>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                            <div class="form-group">
                                <label for="image">Specialisation Name</label>
                                <input type="text" name="specialisation" required class="form-control" />
                            </div>
                            
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>