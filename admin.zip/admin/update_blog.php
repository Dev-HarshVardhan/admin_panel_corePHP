<?php
require_once("header.php");
require_once("db_connect.php");

if (isset($_GET['update_id'])) {
    $id = $_GET['update_id'];

    $sql = "SELECT * FROM blog WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result);
}
if(isset($_POST['submit'])){
    $post_by=$_POST['post_by'];
    $title=$_POST['title'];
    $description=$_POST['description'];
    if(!empty($_FILES['image']['name']) && !empty($post_by) && !empty($title) && !empty($description)){
        $photo =$_FILES['image']['name'];
        $tmp_path =$_FILES['image']['tmp_name'];
        $allowed_extensions ="/(png|jpeg|jpg|webp|pdf)$/i";
        $file_extension = pathinfo($photo, PATHINFO_EXTENSION);

        if (!preg_match($allowed_extensions, $file_extension)) {
            echo '<script>
                Swal.fire({
                title: "Extension not Allowed!",
                text: "Invalid file format. Allowed formats are: PNG, JPG, JPEG, WEBP.",
                icon: "error"
                });
                </script>';
        }else{
            $upload="photo/blog_image/".$photo;
            if(move_uploaded_file($tmp_path,$upload)){
                $query ="UPDATE blog SET post_by='$post_by', title='$title', description='$description', image='$photo' WHERE id='$id'";
                $execute =mysqli_query($conn,$query);
                if ($execute) {
                    echo '<script>
                        Swal.fire({
                            title: "Success!",
                            text: "Record Updated Successfully",
                            icon: "success"
                        }).then(function(){
                            window.location.href="show_blog.php";
                        });
                    </script>';
                } else {
                    echo 'Error updating record.';
                }
            }
        }
    }
    else{
        echo '<script>
        Swal.fire({
        title: "OOps!",
        text: "Please Fill the all Fields",
        icon: "error"
        });
        </script>';
    }
}

?>


<div class="row news-section mt-5">
    <div class="col-md-7 mx-auto mt-5 ">
        <div class="card">
             <div class="card-header">
                <div class="card-title text-center">Update Blog </div>
            </div>
        <form method="POST" enctype="multipart/form-data">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-10 mx-auto">
                        <div class="form-group">
                                <label for="image">Posted By</label>
                                <input type="text" value="<?php echo $data['post_by']; ?>" name="post_by"   class="form-control" />
                            </div>
                        <div class="form-group">
                                <label for="image">Title</label>
                                <input type="text" value="<?php echo $data['title']; ?>" name="title"   class="form-control" />
                            </div>
                        <div class="form-group">
                                <label for="">Description</label>
                                <textarea  id="editor1" value="" name="description"   id="editor1" class="form-control"><?php echo $data['description']; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="image">Blog Image</label>
                                <input type="file" name="image"  class="form-control" />
                                <img src="photo/blog_image/<?php echo $data['image']; ?>" height="50px" alt="">
                            </div>
                            
                            <div class="form-group">
                                <button class="btn btn-success" type="submit" name="submit">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.ckeditor.com/4.4.5/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('editor1');
    </script>