<?php 
require_once('header.php');
require_once('db_connect.php');
?>
<?php
// Adjust the SQL query to perform the LEFT JOIN between 'state' and 'district' tables
$sql = "
    SELECT 
        district.id,
        district.district_name,
        states.state_name
    FROM 
        district
    LEFT JOIN 
        states 
    ON 
        district.state_id = states.id
";
$result = mysqli_query($conn,$sql);
$num_rows = mysqli_num_rows($result);
?>

<div class="row mb-5 mt-5" style="margin-top:40px;">
    <div class="col-md-12 mt-5">
        <div class="card">
            <div class="card-header">
                <div class="card-title text-center">Show District</div>
            </div>
        </div>
        <div class="col-md-12">
            <table id="example" class="table table-striped table-bordered" width="100%">
                <thead>
                    <tr>
                        <th>Sr no</th>
                        <th>State Name</th>
                        <th>District Name</th>
                        <th>Operations</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($num_rows > 0): ?>
                        <?php $i=1; ?>
                        <?php while($data = mysqli_fetch_assoc($result)) : ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo $data['state_name']; ?></td>
                                <td><?php echo $data['district_name']; ?></td>
                                <td>
                                    <a href="update_district.php?update_id=<?php echo $data['id']; ?>"><button class="btn btn-sm btn-primary mb-2">Update</button></a>
                                    <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $data['id'] ?>)"><button class="btn btn-sm btn-danger mb-2">Delete</button></a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Are you sure you want to delete the record?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "delete_district.php?delete_id=" + id;
                }
            })
        }
    </script>
