<?php
require_once('db_connect.php');
session_start();
if(!isset($_SESSION['email'])) {
   
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Dr. Suresh Mandal</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../assets/img/fav.png" type="image/x-icon"/>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.12.1/dist/sweetalert2.all.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.12.1/dist/sweetalert2.min.css" rel="stylesheet">
	
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="master.style.css">
	<link rel="stylesheet" href="assets/css/plugins.min.css">
	<link rel="stylesheet" href="assets/css/kaiadmin.min.css">
	<link rel="stylesheet" href="assets/css/demo.css" />
	<link rel="stylesheet" href="assets/css/all.min.css" />
	<link rel="stylesheet" href="assets/css/demo.css">
	<script src="assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Public Sans:300,400,500,600,700"]},
			custom: {"families":["Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>
	<!---------------- Library ------------------------------------------------>
	 <!--   Core JS Files   -->
	 <script src="assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="assets/js/core/popper.min.js"></script>
    <script src="assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

    <!-- Chart JS -->
    <script src="assets/js/plugin/chart.js/chart.min.js"></script>

    <!-- jQuery Sparkline -->
    <script src="assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

    <!-- Chart Circle -->
    <script src="assets/js/plugin/chart-circle/circles.min.js"></script>

    <!-- Datatables -->
    <script src="assets/js/plugin/datatables/datatables.min.js"></script>

    <!-- Bootstrap Notify -->
    <script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

    <!-- jQuery Vector Maps -->
    <script src="assets/js/plugin/jsvectormap/jsvectormap.min.js"></script>
    <script src="assets/js/plugin/jsvectormap/world.js"></script>

    <!-- Sweet Alert -->
    <script src="assets/js/plugin/sweetalert/sweetalert.min.js"></script>

    <!-- Kaiadmin JS -->
    <script src="assets/js/kaiadmin.min.js"></script>

    <!-- Kaiadmin DEMO methods, don't include it in your project! -->
    <script src="assets/js/setting-demo.js"></script>
    <script src="assets/js/demo.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
    <script>
      
    </script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>

</head>
<body>
	<div class="container-fluide">
	<div class="wrapper">
		<!-- Sidebar -->
		<div class="sidebar" data-background-color="dark">
			<div class="sidebar-logo">
				<!-- Logo Header -->
				<div class="logo-header" data-background-color="dark">

					<a href="#" class="logo">
						<img src="../new-images/logo2.png" alt="navbar brand" class="navbar-brand " height="40">
					</a>
					<div class="nav-toggle">
						<button class="btn btn-toggle toggle-sidebar">
							<i class="gg-menu-right"></i>
						</button>
						<button class="btn btn-toggle sidenav-toggler">
							<i class="gg-menu-left"></i>
						</button>
					</div>
					<button class="topbar-toggler more">
						<i class="gg-more-vertical-alt"></i>
					</button>
				</div>
				<!-- End Logo Header -->	
			</div>	
			<div class="sidebar-wrapper scrollbar scrollbar-inner">
				<div class="sidebar-content">
					<ul class="nav nav-secondary">
						<li class="nav-item">
							<a data-bs-toggle="collapse" href="#dashboard" class="collapsed" aria-expanded="false">
								<a href="dashboard.php">
								<i class="fas fa-home"></i>
								<p>Dashboard</p>
								</a>
							</a>
							
						</li>	
						<li class="nav-item">
							<a data-bs-toggle="collapse" href="#State">
							<i class="fas fa-layer-group"></i>
								<p>State</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="State">
							<ul class="nav nav-collapse">
								<li>
								<a href="add_state.php">
								<span class="sub-item">Add State</span>
								</a>
								</li>
								<li>
								<a href="show_state.php">
								<span class="sub-item">Show State</span>
								</a>
								</li>
							</ul>
							</div>
						</li>		
						<li class="nav-item">
							<a data-bs-toggle="collapse" href="#District">
							<i class="fas fa-layer-group"></i>
								<p>District</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="District">
							<ul class="nav nav-collapse">
							<li>
								<a href="add_district.php">
								<span class="sub-item">Add District</span>
								</a>
								</li>
								<li>
								<a href="show_district.php">
								<span class="sub-item">Show District</span>
								</a>
								</li>
							</ul>
							</div>
						</li>
						<!--<li class="nav-item">-->
						<!--	<a data-bs-toggle="collapse" href="#City">-->
						<!--	<i class="fas fa-layer-group"></i>-->
						<!--		<p>City</p>-->
						<!--		<span class="caret"></span>-->
						<!--	</a>-->
						<!--	<div class="collapse" id="City">-->
						<!--	<ul class="nav nav-collapse">-->
						<!--	<li>-->
						<!--		<a href="add_city.php">-->
						<!--		<span class="sub-item">Add City</span>-->
						<!--		</a>-->
						<!--		</li>-->
						<!--		<li>-->
						<!--		<a href="show_city.php">-->
						<!--		<span class="sub-item">Show City</span>-->
						<!--		</a>-->
						<!--		</li>-->
						<!--	</ul>-->
						<!--	</div>-->
						<!--</li>-->
						<li class="nav-item">
							<a data-bs-toggle="collapse" href="#Specialisation">
							<i class="fas fa-layer-group"></i>
								<p>Specialisation</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="Specialisation">
							<ul class="nav nav-collapse">
							<li>
								<a href="add_specialisation.php">
								<span class="sub-item">Add Specialisation</span>
								</a>
								</li>
								<li>
								<a href="show_specialisation.php">
								<span class="sub-item">Show Specialisation</span>
								</a>
								</li>
							</ul>
							</div>
						</li>
						<li class="nav-item">
							<a data-bs-toggle="collapse" href="#Contact">
							<i class="fas fa-layer-group"></i>
								<p>Contact-us</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="Contact">
							<ul class="nav nav-collapse">
							<li>
								<a href="show_contact.php">
								<span class="sub-item">Show Contact</span>
								</a>
								</li>
							</ul>
							</div>
						</li>
						<li class="nav-item">
							<a data-bs-toggle="collapse" href="#Transaction">
							<i class="fas fa-layer-group"></i>
								<p>Transaction</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="Transaction">
							<ul class="nav nav-collapse">
							<li>
								<a href="show_transaction.php">
								<span class="sub-item">Show Transaction</span>
								</a>
								</li>
							</ul>
							</div>
						</li>
						<li class="nav-item">
							<a data-bs-toggle="collapse" href="#Serives">
							<i class="fas fa-layer-group"></i>
								<p>Serives vise Transaction</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="Serives">
							<ul class="nav nav-collapse">
							<li>
								<a href="show_services_transaction.php">
								<span class="sub-item">Show Transaction</span>
								</a>
								</li>
							</ul>
							</div>
						</li>
						<li class="nav-item">
							<a data-bs-toggle="collapse" href="#Gallery">
							<i class="fas fa-layer-group"></i>
								<p>Gallery</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="Gallery">
							<ul class="nav nav-collapse">
							<li>
								<a href="add_gallery.php">
								<span class="sub-item">Add Gallery</span>
								</a>
							</li>
							<li>
								<a href="show_gallery.php">
								<span class="sub-item">Show Gallery</span>
								</a>
							</li>
							</ul>
							</div>
						</li>
						<li class="nav-item">
							<a data-bs-toggle="collapse" href="#Blog">
							<i class="fas fa-layer-group"></i>
								<p>Blog</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="Blog">
							<ul class="nav nav-collapse">
							<li>
								<a href="add_blog.php">
								<span class="sub-item">Add Blog</span>
								</a>
							</li>
							<li>
								<a href="show_blog.php">
								<span class="sub-item">Show Blog</span>
								</a>
							</li>
							</ul>
							</div>
						</li>			
					
						
					</ul>
				</div>
			</div>
		</div>
		<!-- End Sidebar -->

		<div class="main-panel">
			<div class="main-header">
				<div class="main-header-logo">
					<!-- Logo Header -->
					<div class="logo-header" data-background-color="dark">

						<a href="index.php" class="logo">
							<img src="../new-images/logo2.png" alt="navbar brand" class="navbar-brand" height="35">
						</a>
						<div class="nav-toggle">
							<button class="btn btn-toggle toggle-sidebar">
								<i class="gg-menu-right"></i>
							</button>
							<button class="btn btn-toggle sidenav-toggler">
								<i class="gg-menu-left"></i>
							</button>
						</div>
						<button class="topbar-toggler more">
							<i class="gg-more-vertical-alt"></i>
						</button>

					</div>
					<!-- End Logo Header -->
				</div>
				<!-- Navbar Header -->
				<nav class="navbar navbar-header navbar-header-transparent navbar-expand-lg border-bottom">

					<div class="container-fluid">
						<nav class="navbar navbar-header-left navbar-expand-lg navbar-form nav-search p-0 d-none d-lg-flex">
							<div class="input-group">
								<div class="input-group-prepend">
									<button type="submit" class="btn btn-search pe-1">
										<i class="fa fa-search search-icon"></i>
									</button>
								</div>
								<input type="text" placeholder="Search ..." class="form-control">
							</div>
						</nav>

						<ul class="navbar-nav topbar-nav ms-md-auto align-items-center">
							<li class="nav-item topbar-icon dropdown hidden-caret d-flex d-lg-none">
								<a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" aria-haspopup="true">
									<i class="fa fa-search"></i>
								</a>
								<ul class="dropdown-menu dropdown-search animated fadeIn">
									<form class="navbar-left navbar-form nav-search">
										<div class="input-group">
											<input type="text" placeholder="Search ..." class="form-control">
										</div>
									</form>
								</ul>
							</li>
							
							
							
							
							<li class="nav-item topbar-user dropdown hidden-caret">
								<a class="dropdown-toggle profile-pic" data-bs-toggle="dropdown" href="#" aria-expanded="false">
									<div class="avatar-sm">
										<img src="assets/img/profile.jpg" alt="..." class="avatar-img rounded-circle">
									</div>
									<span class="profile-username">
										<span class="op-7"></span> <span class="fw-bold">
                                        <?php
                                           if(isset($_SESSION['email'])) {
                                              echo $_SESSION['email'];
                                           }
                                        ?>
                                        </span>
									</span>
								</a>
								<ul class="dropdown-menu dropdown-user animated fadeIn">
									<div class="dropdown-user-scroll scrollbar-outer">
										<li>
											<div class="user-box">
												<div class="avatar-lg"><img src="assets/img/profile.jpg" alt="image profile" class="avatar-img rounded"></div>
												<div class="u-text">
													<h4>Admin</h4>
													<p class="text-muted"><?php echo $_SESSION['email']; ?></p><a href="logout.php" class="btn btn-xs btn-secondary btn-sm w-75">Logout</a>
												</div>
											</div>
										</li>
										
									</div>
								</ul>
							</li>
						</ul>
					</div>
				</nav>
				<!--------------------------------------- End Navbar----------------------------------------->
			</div>
			
	