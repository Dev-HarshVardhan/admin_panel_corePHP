<?php 
require_once('header.php');
?>
<?php
$sql="select * from contact_us";
$result=mysqli_query($conn,$sql);
$num_rows=mysqli_num_rows($result);
?>
<script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Are you sure you want to delete the record?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "delete_contact.php?delete_id=" + id;
                }
            })
        }
    </script>

<div class="row mb-5" style="margin-top:40px;">
    <div class="col-md-12 mt-5" >
        <div class="card">
            <div class="card-header">
            <div class="card-title text-center">Show Contact Data</div>
            </div>
        </div>
        <div class="col-md-12">
        <table id="example" class="table table-striped table-bordered" width="100%">
                <thead>
                    <tr>
                        <th>Sr no</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Message</th>
                        <th >Operations</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($num_rows > 0): ?>
                        <?php $i=1; ?>
                        <?php while($data=mysqli_fetch_assoc($result)) : ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo $data['fname']; ?></td>
                                <td><?php echo $data['lname']; ?></td>
                                <td><?php echo $data['email']; ?></td>
                                <td><?php echo $data['phone']; ?></td>
                                <td><?php echo $data['message']; ?></td>
                                <td>
                                    <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $data['id'] ?>)"><button class="btn btn-sm btn-danger mb-2">Delete</button></a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

