<?php 
require_once('header.php');
?>
<?php
$sql="select * from payment";
$result=mysqli_query($conn,$sql);
$num_rows=mysqli_num_rows($result);
?>
<script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Are you sure you want to delete the record?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "delete_transaction.php?delete_id=" + id;
                }
            })
        }
    </script>

<div class="row mb-5" style="margin-top:40px;">
    <div class="col-md-12 mt-5" >
        <div class="card">
            <div class="card-header">
            <div class="card-title text-center">Show Transaction</div>
            </div>
        </div>
        <div class="col-md-12">
        <table id="example" class="table table-striped table-bordered" width="100%">
                <thead>
                    <tr>
                        <th>Sr no</th>
                        <th>Order Id</th>
                        <th >Amount</th>
                        <th >Name</th>
                        <th >Email</th>
                        <th >Phone</th>
                        <th >Date</th>
                        <th >State</th>
                        <th >District</th>
                        <th >City</th>
                        <th >Payment Status</th>
                        <th >Service</th>
                        <th >Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($num_rows > 0): ?>
                        <?php $i=1; ?>
                        <?php while($data=mysqli_fetch_assoc($result)) : ?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo $data['order_id']; ?></td>
                                <td><?php echo $data['amount']; ?></td>
                                <td><?php echo $data['name']; ?></td>
                                <td><?php echo $data['email']; ?></td>
                                <td><?php echo $data['phone']; ?></td>
                                <td><?php echo $data['date']; ?></td>
                                <td><?php echo $data['state']; ?></td>
                                <td><?php echo $data['district']; ?></td>
                                <td><?php echo $data['city']; ?></td>
                                
                                    <?php if($data['payment_status'] == "success"): ?>
                                         <td style="color:green; font-weight:bold;font-size:18px;"> <?php echo $data['payment_status']; ?></td>
                                    <?php else: ?>
                                        <td style="color: red; font-weight:bold;font-size:18px;"> <?php echo $data['payment_status']; ?></td>
                                    <?php endif; ?>
                               
                                <td><?php echo $data['service']; ?></td>
                                <td>
                                    <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $data['id'] ?>)"><button class="btn btn-sm btn-danger mb-2">Delete</button></a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

