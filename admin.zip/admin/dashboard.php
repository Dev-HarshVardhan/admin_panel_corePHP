<?php

require_once("header.php");

if (isset($_SESSION['login_success']) && $_SESSION['login_success']) {
    echo "<script>
            Swal.fire({
                title: 'Success!',
                text: 'Login successful.',
                icon: 'success'
            });
          </script>";

    unset($_SESSION['login_success']);
}

require_once('db_connect.php');
?>
?>

        <div class="container">
          <div class="page-inner">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4">
              <div>
                <h3 class="fw-bold mb-3">Dashboard</h3>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                  <div class="card-body">
                    <div class="row align-items-center">
                      <div class="col-icon">
                        <div class="icon-big text-center icon-pr imary bubble-shadow-small">
                          <i class="fas fa-users"></i>
                        </div>
                      </div>
                      <div class="col col-stats ms-3 ms-sm-0">
                        <div class="numbers">
                          <p class="card-category ">States</p>
                          <?php 
                          $sql="SELECT COUNT(*) AS total FROM states";
                           $result=mysqli_query($conn,$sql);
                           $num_rows=mysqli_num_rows($result);
                           ?>
                            <?php if($num_rows > 0): ?>
                            <?php  while($row=mysqli_fetch_assoc($result)): ?>
                             <h4 class="card-title"><?php echo $row['total'];?></h4>
                            <?php endwhile;?>
                            <?php endif;?>
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                  <div class="card-body">
                    <div class="row align-items-center">
                      <div class="col-icon">
                        <div
                          class="icon-big text-center icon-info bubble-shadow-small"
                        >
                          <i class="fas fa-user-check"></i>
                        </div>
                      </div>
                      <div class="col col-stats ms-3 ms-sm-0">
                        <div class="numbers">
                          <p class="card-category">District</p>
                          <?php 
                          $sql="SELECT COUNT(*) AS total FROM district";
                           $result=mysqli_query($conn,$sql);
                           $num_rows=mysqli_num_rows($result);
                           ?>
                            <?php if($num_rows > 0): ?>
                            <?php  while($row=mysqli_fetch_assoc($result)): ?>
                             <h4 class="card-title"><?php echo $row['total'];?></h4>
                            <?php endwhile;?>
                            <?php endif;?>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                  <div class="card-body">
                    <div class="row align-items-center">
                      <div class="col-icon">
                        <div
                          class="icon-big text-center icon-success bubble-shadow-small"
                        >
                          <i class="fas fa-luggage-cart"></i>
                        </div>
                      </div>
                      <div class="col col-stats ms-3 ms-sm-0">
                        <div class="numbers">
                          <p class="card-category">Contact-us</p>
                          <?php 
                          $sql="SELECT COUNT(*) AS total FROM contact_us";
                           $result=mysqli_query($conn,$sql);
                           $num_rows=mysqli_num_rows($result);
                           ?>
                            <?php if($num_rows > 0): ?>
                            <?php  while($row=mysqli_fetch_assoc($result)): ?>
                             <h4 class="card-title"><?php echo $row['total'];?></h4>
                            <?php endwhile;?>
                            <?php endif;?>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6 col-md-3">
                <div class="card card-stats card-round">
                  <div class="card-body">
                    <div class="row align-items-center">
                      <div class="col-icon">
                        <div
                          class="icon-big text-center icon-secondary bubble-shadow-small"
                        >
                          <i class="far fa-check-circle"></i>
                        </div>
                      </div>
                      <div class="col col-stats ms-3 ms-sm-0">
                        <div class="numbers">
                          <p class="card-category">Gallery</p>
                          <?php 
                          $sql="SELECT COUNT(*) AS total FROM gallery";
                           $result=mysqli_query($conn,$sql);
                           $num_rows=mysqli_num_rows($result);
                           ?>
                            <?php if($num_rows > 0): ?>
                            <?php  while($row=mysqli_fetch_assoc($result)): ?>
                             <h4 class="card-title"><?php echo $row['total'];?></h4>
                            <?php endwhile;?>
                            <?php endif;?>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
